<?php
date_default_timezone_set('Europe/Moscow');
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../storage/logs/ItemRepairController.log');

require_once __DIR__ . '/../BusinessLogic/ItemController.php';

require_once __DIR__ . '/../Repositories/RepairItemRepository.php';
require_once __DIR__ . '/Action.php';
require_once __DIR__ . '/../Repositories/InventoryItemRepository.php';
require_once __DIR__ . '/../Repositories/LocationRepository.php';

require_once __DIR__ . '/../Entity/RepairItem.php';

require_once __DIR__ . '/../Database/DatabaseFactory.php';
require_once 'HistoryOperationsController.php';
require_once 'StatusItem.php';
require_once 'OperationType.php';
require_once 'StatusUser.php';



class ItemRepairController
{
    private Container $container;
    private Logger $logger;
    private CUDFactory $cudFactory;
    public function __construct()
    {
        $this->container = new Container();
        $this->container->set(Database::class, function () {
            return DatabaseFactory::create();
        });

        $this->container->set(Logger::class, function () {
            return new Logger(__DIR__ . '/../storage/logs/ItemRepairController.log');
        });
        $this->logger = $this->container->get(Logger::class);

        $this->cudFactory = new CUDFactory($this->container->get(Database::class), $this->logger, $this->container);
    }

    public function create($data): ?object
    {
        $result = $this->cudFactory->create($data);
        return $result;
    }
    public function update($data): ?object
    {
        $result = $this->cudFactory->update($data);
        return $result;
    }



    public function sendForRepair($data, $filename): ?object
    {
        $ressult = $this->repairManager($data, $filename, OperationType::SEND_REPAIR) ?? null;
        return $ressult;
    }

    /**
     * Кладовщик кидает в сервис — сразу «В ремонте», счёт потом в архиве.
     */
    public function registerPendingServiceSend(int $tmcId, string $note): ?RepairItem
    {
        $inventoryItemRepository = $this->container->get(InventoryItemRepository::class);
        $item = $inventoryItemRepository->findById($tmcId, 'ID_TMC');
        if ($item === null) {
            throw new Exception("ТМЦ {$tmcId} не найден");
        }

        $status = (int) ($item->Status ?? -1);
        if ($status === StatusItem::WrittenOff) {
            throw new Exception("ТМЦ {$tmcId} списан");
        }

        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $openRepairs = $repairItemRepository->findBy(
            'WHERE ID_TMC = ' . (int) $tmcId . ' AND DateReturnService IS NULL ORDER BY ID_Repair'
        );

        $itemController = new ItemController();
        if ($openRepairs !== null && $openRepairs->count() > 0) {
            $itemController->changeStatusTMC($tmcId, StatusItem::ConfirmRepairTMC);
            $itemController->logHistoryOperation(OperationType::ACCEPT_FOR_REPAIR, $tmcId, null, $note);
            return $openRepairs->last();
        }

        if ($status === StatusItem::Repair) {
            throw new Exception("ТМЦ {$tmcId} уже в сервисе — сначала верните из сервиса");
        }

        // Устаревшие записи «Подтвердить ремонт» — переводим в нормальный поток
        if ($status === StatusItem::ConfirmRepairTMC) {
            $description = trim($note) !== '' ? trim($note) : 'Отправлено в сервис';
            $locationId = (int) ($item->IDLocation ?? 0);
            if ($locationId <= 0) {
                $main = $itemController->getMainWarehouse();
                $locationId = (int) ($main->IDLocation ?? 0);
            }
            $repairItem = new RepairItem([
                'ID_TMC' => $tmcId,
                'IDLocation' => $locationId,
                'InvoiceNumber' => '',
                'RepairCost' => 0,
                'RepairDescription' => $description,
                'UPD' => '',
            ]);
            $saved = $repairItemRepository->save($repairItem, Action::CREATE);
            if (!$saved) {
                throw new Exception("Не удалось создать запись ремонта для ТМЦ {$tmcId}");
            }
            $itemController->changeStatusTMC($tmcId, StatusItem::ConfirmRepairTMC);
            $itemController->logHistoryOperation(OperationType::ACCEPT_FOR_REPAIR, $tmcId, null, $description);
            return $saved;
        }

        $locationId = (int) ($item->IDLocation ?? 0);
        if ($locationId <= 0) {
            $main = $itemController->getMainWarehouse();
            $locationId = (int) ($main->IDLocation ?? 0);
        }
        if ($locationId <= 0) {
            throw new Exception("Не указана локация для ТМЦ {$tmcId}");
        }

        $description = trim($note) !== '' ? trim($note) : 'Отправлено в сервис';
        $repairItem = new RepairItem([
            'ID_TMC' => $tmcId,
            'IDLocation' => $locationId,
            'InvoiceNumber' => '',
            'RepairCost' => 0,
            'RepairDescription' => $description,
            'UPD' => '',
        ]);

        $saved = $repairItemRepository->save($repairItem, Action::CREATE);
        if (!$saved) {
            throw new Exception("Не удалось создать запись ремонта для ТМЦ {$tmcId}");
        }

        $itemController->changeStatusTMC($tmcId, StatusItem::ConfirmRepairTMC);
        $itemController->logHistoryOperation(OperationType::ACCEPT_FOR_REPAIR, $tmcId, null, $description);

        return $saved;
    }

    /**
     * Админ согласовал ремонт — сохраняем счёт, переводим в «В ремонте».
     */
    public function approveRepair(int $repairId, int $tmcId, array $data): bool
    {
        $invoice = trim((string) ($data['InvoiceNumber'] ?? ''));
        if ($invoice === '') {
            throw new Exception('Укажите № счёта');
        }

        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        if ($repairId > 0) {
            $current = $repairItemRepository->findById($repairId, 'ID_Repair');
            if (!$current) {
                throw new Exception('Запись ремонта не найдена');
            }
            $this->updateRepair([
                'ID_Repair' => $repairId,
                'ID_TMC' => $tmcId,
                'IDLocation' => (int) ($data['IDLocation'] ?? $current->IDLocation ?? 0),
                'InvoiceNumber' => $invoice,
                'RepairCost' => (float) ($data['RepairCost'] ?? $current->RepairCost ?? 0),
                'RepairDescription' => (string) ($data['RepairDescription'] ?? $current->RepairDescription ?? ''),
                'UPD' => $current->UPD ?? '',
                'inBasket' => 0,
            ]);
        } else {
            $itemController = new ItemController();
            $item = $itemController->getInventoryItem($tmcId);
            $locationId = (int) ($data['IDLocation'] ?? $item->IDLocation ?? 0);
            if ($locationId <= 0) {
                throw new Exception('Не указана организация сервиса');
            }
            $repairItem = new RepairItem([
                'ID_TMC' => $tmcId,
                'IDLocation' => $locationId,
                'InvoiceNumber' => $invoice,
                'RepairCost' => (float) ($data['RepairCost'] ?? 0),
                'RepairDescription' => (string) ($data['RepairDescription'] ?? 'Согласовано'),
                'UPD' => '',
            ]);
            $saved = $repairItemRepository->save($repairItem, Action::CREATE);
            if (!$saved) {
                throw new Exception('Не удалось создать запись ремонта');
            }
        }

        $itemController = new ItemController();
        $itemController->changeStatusTMC($tmcId, StatusItem::Repair);
        $itemController->logHistoryOperation(
            OperationType::SEND_REPAIR,
            $tmcId,
            null,
            $invoice
        );

        return true;
    }

    /**
     * Админ отказал в ремонте — возврат ТМЦ на объект.
     */
    public function rejectRepair(int $tmcId, string $reason = ''): bool
    {
        $itemController = new ItemController();
        $reason = trim($reason) !== '' ? trim($reason) : 'Отказ в согласовании ремонта';
        return $itemController->sendToService($tmcId, 1, $reason);
    }

    /**
     * ТМЦ без счёта + старые записи в статусе ConfirmRepairTMC.
     * @return array<int, object|RepairItem>
     */
    public function getRepairsPendingInvoice(): array
    {
        $items = [];
        $seenTmc = [];

        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $inventoryItemRepository = $this->container->get(InventoryItemRepository::class);
        $locationRepository = $this->container->get(LocationRepository::class);

        $repairItemRepository->addRelationship('InventoryItem', $inventoryItemRepository, 'ID_TMC', 'ID_TMC');
        $repairItemRepository->addRelationship('Location', $locationRepository, 'IDLocation', 'IDLocation');

        $query = "SELECT RepairItem.*, InventoryItem.*, Location.*
            FROM RepairItem
            LEFT JOIN InventoryItem ON RepairItem.ID_TMC = InventoryItem.ID_TMC
            LEFT JOIN Location ON RepairItem.IDLocation = Location.IDLocation
            WHERE RepairItem.inBasket = 0
              AND InventoryItem.Status IN (" . StatusItem::Repair . ", " . StatusItem::ConfirmRepairTMC . ")
              AND (
                RepairItem.InvoiceNumber IS NULL
                OR LTRIM(RTRIM(RepairItem.InvoiceNumber)) = ''
              )
            ORDER BY RepairItem.DateToService DESC";

        $repairs = $repairItemRepository->getAll($query);
        if ($repairs) {
            foreach ($repairs as $repair) {
                $items[] = $repair;
                $seenTmc[(int) $repair->ID_TMC] = true;
            }
        }

        $inventoryItemRepository->addRelationship('Location', $locationRepository, 'IDLocation', 'IDLocation');
        $legacy = $inventoryItemRepository->findBy(
            'WHERE Status = ' . StatusItem::ConfirmRepairTMC . ' ORDER BY NameTMC'
        );
        if ($legacy) {
            foreach ($legacy as $inv) {
                $id = (int) ($inv->ID_TMC ?? 0);
                if ($id > 0 && !isset($seenTmc[$id])) {
                    $items[] = (object) [
                        'ID_Repair' => 0,
                        'ID_TMC' => $id,
                        'isLegacyConfirm' => true,
                        'InventoryItem' => $inv,
                        'RepairDescription' => '',
                        'InvoiceNumber' => '',
                    ];
                }
            }
        }

        return $items;
    }

    public function countRepairsPendingInvoice(): int
    {
        $seen = [];
        foreach ($this->getRepairsPendingInvoice() as $item) {
            $id = (int) ($item->ID_TMC ?? 0);
            if ($id > 0) {
                $seen[$id] = true;
            }
        }
        return count($seen);
    }
    public function writeOffItem($data, $filename): ?object
    {
        $ressult = $this->repairManager($data, $filename, OperationType::WRITE_OFF) ?? null;
        return $ressult;
    }

    /**
     * Списание ТМЦ без отправки в сервис (только админ, с главной таблицы).
     */
    public function directWriteOffByIds(array $tmcIds, string $reason = ''): array
    {
        $written = [];
        $errors = [];
        $atWorkCount = 0;
        $reason = trim($reason) !== '' ? trim($reason) : 'Списание без отправки в сервис';
        $inventoryItemRepository = $this->container->get(InventoryItemRepository::class);
        $blocked = [
            StatusItem::WrittenOff,
            StatusItem::Repair,
            StatusItem::ConfirmRepairTMC,
        ];

        foreach ($tmcIds as $rawId) {
            $id = (int) $rawId;
            if ($id <= 0) {
                continue;
            }

            $item = $inventoryItemRepository->findById($id, 'ID_TMC');
            if (!$item) {
                $errors[] = "ТМЦ {$id} не найден";
                continue;
            }

            $status = (int) ($item->Status ?? -1);
            if (in_array($status, $blocked, true)) {
                $errors[] = "ТМЦ {$id}: нельзя списать из статуса «" . (StatusItem::getDescription($status) ?? $status) . "»";
                continue;
            }

            $locationId = (int) ($item->IDLocation ?? 0);
            if ($locationId <= 0) {
                $errors[] = "ТМЦ {$id}: не указана локация";
                continue;
            }

            $this->writeOffItem([
                'ID_TMC' => $id,
                'IDLocation' => $locationId,
                'InvoiceNumber' => 'Без счета',
                'UPD' => '',
                'RepairCost' => 0,
                'RepairDescription' => $reason,
            ], null);

            if ($status === StatusItem::AtWorkTMC) {
                $atWorkCount++;
            }
            $written[] = $id;
        }

        return [
            'written' => $written,
            'errors' => $errors,
            'atWorkCount' => $atWorkCount,
        ];
    }

    private function repairManager($data, $filename, $operationType): ?object
    {
        $ID_TMC = isset($data['ID_TMC']) ? (int) $data['ID_TMC'] : 0;
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $repairItem = new RepairItem($data);
        $repairItem->UPD = $filename ?? null;
        if ($operationType === OperationType::SEND_REPAIR)
            $repairItem->DateReturnService = null;
        else
            $repairItem->DateReturnService = (new \DateTime())->format('Y-m-d H:i:s');
        $repair = $repairItemRepository->save($repairItem, Action::CREATE);
        if (!$repair) {
            throw new Exception("Ошибка создания repair в repairManager. RepairCost = {$repairItem->RepairCost}");
        }

        //error_log('Передача ID_TMC');
        //error_log($ID_TMC);
        $itemController = new ItemController();
        if ($operationType === OperationType::WRITE_OFF) {
            $itemController->unlinkFromBrigade($ID_TMC);
        }
        $itemController->changeStatusTMC(
            $ID_TMC,
            OperationType::getStatusTransition($operationType)
        );

        $historyNote = $repairItem->InvoiceNumber ?? '';
        if ($operationType === OperationType::WRITE_OFF) {
            $historyNote = trim((string) ($repairItem->RepairDescription ?? '')) !== ''
                ? (string) $repairItem->RepairDescription
                : (string) ($repairItem->InvoiceNumber ?? 'Списание');
        }

        $itemController->logHistoryOperation(
            $operationType,
            $ID_TMC,
            null,
            $historyNote
        );
        return $repairItem;
    }

    public function updateRepair($data): bool
    {
        //$this->logger->log('updateRepair', "1");
        $repairItemRepository = $this->container->get(RepairItemRepository::class);

        $repairData = new RepairItem($data);
        // Получаем текущую запись о ремонте из базы
        $currentRepair = $repairItemRepository->findById($repairData->ID_Repair, 'ID_Repair');
        if (!$currentRepair) {
            throw new Exception("Запись о ремонте с ID {$repairData->ID_Repair} не найдена");
        }

        //$this->logger->log('updateRepair', "3");
        $changed = false;
        $persistableProps = $currentRepair->getPersistableProperties();
        $readOnlyFields = $currentRepair->getReadOnlyFields();



        foreach ($persistableProps as $prop) {
            // Пропускаем read-only поля
            if (in_array($prop, $readOnlyFields)) {
                continue;
            }

            // Если в переданных данных нет этого свойства, пропускаем
            if (!property_exists($repairData, $prop)) {
                continue;
            }

            $newValue = $repairData->$prop;
            $currentValue = $currentRepair->$prop;

            // Приведение типа нового значения к типу текущего значения
            if (is_int($currentValue)) {
                $newValue = (int) $newValue;
            } elseif (is_float($currentValue)) {
                $newValue = (float) $newValue;
            } elseif (is_bool($currentValue)) {
                $newValue = filter_var($newValue, FILTER_VALIDATE_BOOLEAN);
            }

            // Сравниваем значения
            if ($currentValue !== $newValue) {
                $changed = true;
                $currentRepair->$prop = $newValue;
            }
        }

        // Если есть изменения, сохраняем
        if ($changed) {
            $result = $repairItemRepository->save($currentRepair);
            //$result = true;
            return $result !== null ? true : false;
        }

        // Если изменений нет, возвращаем true
        return false;
    }

    public function writeOffItems(): ?Collection
    {
        //$repairItemRepository = $this->container->get(RepairItemRepository::class);
        $inventoryItemRepository = $this->container->get(InventoryItemRepository::class);
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $locationRepository = $this->container->get(LocationRepository::class);
        $userRepository = $this->container->get(UserRepository::class);
        $registrationInventoryItemRepository = $this->container->get(RegistrationInventoryItemRepository::class);
        $brandTMCRepository = $this->container->get(BrandTMCRepository::class);

        /* $query = " LEFT JOIN RegistrationInventoryItem ON RepairItem.ID_TMC = RegistrationInventoryItem.IDRegItem "            
             . " WHERE inBasket = 0"
             . " SELECT *FROM InventoryItem WHERE Status = " . StatusItem::Repair . " or Status =" . StatusItem::WrittenOff
             . " SELECT *FROM Location"            
             . " SELECT *FROM [User]";*/

        /* $query = "LEFT JOIN RegistrationInventoryItem ON RepairItem.ID_TMC = RegistrationInventoryItem.IDRegItem
           LEFT JOIN InventoryItem ON RegistrationInventoryItem.IDRegItem = InventoryItem.ID_TMC
           LEFT JOIN Location ON Location.IDLocation = RepairItem.IDLocation
           WHERE RepairItem.inBasket = 0";*/

        /*  $query = "LEFT JOIN InventoryItem ON RepairItem.ID_TMC = InventoryItem.ID_TMC
            LEFT JOIN RegistrationInventoryItem ON InventoryItem.ID_TMC = RegistrationInventoryItem.IDRegItem
            LEFT JOIN Location ON InventoryItem.IDLocation = Location.IDLocation
            LEFT JOIN BrandTMC ON InventoryItem.IDBrandTMC = BrandTMC.IDBrandTMC
            LEFT JOIN User ON RegistrationInventoryItem.CurrentUser = User.IDUser          
            WHERE RepairItem.inBasket = 0";*/

        $query = "SELECT 
            RepairItem.*,
            InventoryItem.*,
            Location.*,
            BrandTMC.*,
            [User].*,
            RegistrationInventoryItem.*
        FROM RepairItem
        LEFT JOIN InventoryItem ON RepairItem.ID_TMC = InventoryItem.ID_TMC
        LEFT JOIN Location ON InventoryItem.IDLocation = Location.IDLocation
        LEFT JOIN BrandTMC ON InventoryItem.IDBrandTMC = BrandTMC.IDBrandTMC
        LEFT JOIN RegistrationInventoryItem ON InventoryItem.ID_TMC = RegistrationInventoryItem.IDRegItem
        LEFT JOIN [User] ON RegistrationInventoryItem.CurrentUser = [User].IDUser
        WHERE RepairItem.inBasket = 0
        AND InventoryItem.Status IN (" . StatusItem::Repair . ", " . StatusItem::ConfirmRepairTMC . ")";

        $repairItemRepository->addRelationship('Location', $locationRepository, 'IDLocation', 'IDLocation');
        $repairItemRepository->addRelationship('InventoryItem', $inventoryItemRepository, 'ID_TMC', 'ID_TMC');



        /*     $query = "LEFT JOIN RegistrationInventoryItem ON RepairItem.ID_TMC = RegistrationInventoryItem.IDRegItem
                 LEFT JOIN Location ON Location.IDLocation = RepairItem.IDLocation
                 LEFT JOIN User ON RegistrationInventoryItem.CurrentUser = User.IDUser                        
                 LEFT JOIN InventoryItem ON RepairItem.ID_TMC = InventoryItem.ID_TMC                  
                 WHERE RepairItem.inBasket = 0";*/


        /*   $query = "LEFT JOIN Location ON Location.IDLocation = RepairItem.IDLocation                                       
                   LEFT JOIN InventoryItem ON RepairItem.ID_TMC = InventoryItem.ID_TMC                  
                   WHERE RepairItem.inBasket = 0";*/

        // Добавляем отношения для RepairItem
        /* $repairItemRepository->addRelationship(
             'Location',
             $locationRepository,
             'IDLocation',
             'IDLocation'
         );

         $repairItemRepository->addRelationship(
             'InventoryItem',
             $inventoryItemRepository,
             'ID_TMC',
             'ID_TMC'
         );

         // Добавляем отношения для InventoryItem
         $inventoryItemRepository->addRelationship(
             'BrandTMC',
             $brandTMCRepository,
             'IDBrandTMC',
             'IDBrandTMC'
         );

         $inventoryItemRepository->addRelationship(
             'Location',
             $locationRepository,
             'IDLocation',
             'IDLocation'
         );

         $inventoryItemRepository->addRelationship(
             'User',
             $userRepository,
             'CurrentUser',
             'IDUser'
         );*/


        $repairItems = $repairItemRepository->getAll($query);

        //error_log(print_r($repairItems, true));

        return $repairItems;


    }

    /**
     * Summary of RepairInBasket
     * @param mixed $ID_TMC
     * @return bool
     */
    public function RepairInBasket($ID_TMC): bool
    {
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $repairItems = $repairItemRepository->findBy("WHERE ID_TMC = {$ID_TMC}");
        if (!$repairItems) {
            return false;
        }

        foreach ($repairItems as $item) {
            //$this->logger->log("Найден ТМЦ", "", $item);
            //error_log(print_r($item, true));
            $inBasket = $item->inBasket ? false : true;
            $item->inBasket = $inBasket;
            $result = $repairItemRepository->save($item);
            if ($result == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Переместить одну запись ремонта в корзину
     */
    public function RepairRecordInBasket(int $ID_Repair): bool
    {
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $item = $repairItemRepository->findById($ID_Repair, 'ID_Repair');
        if (!$item) {
            return false;
        }
        $item->inBasket = true;
        return $repairItemRepository->save($item) !== null;
    }

    public function getBasketItems(): ?Collection
    {
        $inventoryItemRepository = $this->container->get(InventoryItemRepository::class);
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $locationRepository = $this->container->get(LocationRepository::class);

        $query = "LEFT JOIN RegistrationInventoryItem ON RepairItem.ID_TMC = RegistrationInventoryItem.IDRegItem
          LEFT JOIN InventoryItem ON RegistrationInventoryItem.IDRegItem = InventoryItem.ID_TMC
          WHERE RepairItem.inBasket = 1";

        $repairItemRepository->addRelationship(
            'Location',
            $locationRepository,
            'IDLocation',
            'IDLocation'
        );

        $repairItemRepository->addRelationship(
            'InventoryItem',
            $inventoryItemRepository,
            'ID_TMC',
            'ID_TMC'
        );

        return $repairItemRepository->findBy($query);
    }

    public function returnFromBasket($ID_TMC): bool
    {
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $repairItems = $repairItemRepository->findBy("WHERE ID_TMC = {$ID_TMC}");

        foreach ($repairItems as $item) {
            $item->inBasket = false;
            $result = $repairItemRepository->save($item);
            if ($result == null)
                return false;
        }
        return true;
    }

    public function getItemWithRepairs($ID_TMC, ?int $ID_Repair = null): ?Collection
    {
        //$repairItemRepository = $this->container->get(RepairItemRepository::class);
        $inventoryItemRepository = $this->container->get(InventoryItemRepository::class);
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $locationRepository = $this->container->get(LocationRepository::class);

        $repairFilter = $ID_Repair ? " AND RepairItem.ID_Repair = {$ID_Repair}" : "";

        $query = "LEFT JOIN RegistrationInventoryItem ON RepairItem.ID_TMC = RegistrationInventoryItem.IDRegItem
          LEFT JOIN InventoryItem ON RegistrationInventoryItem.IDRegItem = InventoryItem.ID_TMC
          LEFT JOIN Location ON Location.IDLocation = RepairItem.IDLocation
          WHERE RepairItem.ID_TMC = {$ID_TMC}
            AND RepairItem.inBasket = 0
            {$repairFilter}";

        $repairItemRepository->addRelationship(
            'Location',                             // Свойство в Location для связи
            $locationRepository,                    // Репозиторий связанной сущности
            'IDLocation',                           // Внешний ключ в InventoryItem
            'IDLocation'                            // Первичный ключ в Location
        );

        $repairItemRepository->addRelationship(
            'InventoryItem',
            $inventoryItemRepository,
            'ID_TMC',
            'ID_TMC'
        );

        return $repairItemRepository->findBy($query);
    }

    /**
     * Списанные ТМЦ с историей ремонтов (для реестра «Все списанные»)
     * Берём по InventoryItem.Status, чтобы не показывать ТМЦ с прошлыми ремонтами.
     */
    public function getWrittenOffGroupedItems(): array
    {
        $inventoryItemRepository = $this->container->get(InventoryItemRepository::class);
        $repairItemRepository = $this->container->get(RepairItemRepository::class);
        $locationRepository = $this->container->get(LocationRepository::class);

        $statusWrittenOff = (int) StatusItem::WrittenOff;

        $sql = "
            SELECT
                ii.ID_TMC,
                ii.NameTMC,
                ii.SerialNumber,
                ii.Status,
                ii.IDBrandTMC,
                ii.IDLocation,
                l.NameLocation,
                l.FormsJointStockCompanies AS LocationLegalEntity,
                b.NameBrand,
                r.IDRegItem,
                r.CurrentUser,
                u.Surname,
                u.Name,
                u.Patronymic
            FROM InventoryItem ii
            LEFT JOIN Location l ON ii.IDLocation = l.IDLocation
            LEFT JOIN BrandTMC b ON ii.IDBrandTMC = b.IDBrandTMC
            LEFT JOIN RegistrationInventoryItem r ON ii.ID_TMC = r.IDRegItem
            LEFT JOIN [User] u ON r.CurrentUser = u.IDUser
            WHERE ii.Status = {$statusWrittenOff}
            ORDER BY ii.ID_TMC DESC
        ";

        $rows = $inventoryItemRepository->getAll_array($sql) ?? [];
        if (!$rows) {
            return [];
        }

        $ids = array_map(static fn($row) => (int) ($row['ID_TMC'] ?? 0), $rows);
        $ids = array_values(array_filter($ids));
        $idsList = implode(',', $ids);

        $repairItemRepository->addRelationship('Location', $locationRepository, 'IDLocation', 'IDLocation');
        $repairsByTmc = [];
        if ($idsList !== '') {
            $repairQuery = "
                SELECT RepairItem.*
                FROM RepairItem
                WHERE RepairItem.inBasket = 0
                  AND RepairItem.ID_TMC IN ({$idsList})
                ORDER BY RepairItem.ID_Repair DESC
            ";
            $repairItems = $repairItemRepository->getAll($repairQuery);
            if ($repairItems) {
                foreach ($repairItems as $repair) {
                    $tmcId = (int) $repair->ID_TMC;
                    $repairsByTmc[$tmcId][] = $repair;
                }
            }
        }

        $grouped = [];
        foreach ($rows as $row) {
            $tmcId = (int) ($row['ID_TMC'] ?? 0);
            if ($tmcId <= 0) {
                continue;
            }

            $inventoryItem = new InventoryItem([
                'ID_TMC' => $tmcId,
                'NameTMC' => $row['NameTMC'] ?? '',
                'SerialNumber' => $row['SerialNumber'] ?? null,
                'Status' => (int) ($row['Status'] ?? $statusWrittenOff),
                'IDBrandTMC' => (int) ($row['IDBrandTMC'] ?? 0),
                'IDLocation' => (int) ($row['IDLocation'] ?? 0),
                'LocationLegalEntity' => $row['LocationLegalEntity'] ?? '',
            ]);

            $inventoryItem->Location = new Location([
                'IDLocation' => (int) ($row['IDLocation'] ?? 0),
                'NameLocation' => $row['NameLocation'] ?? '',
                'FormsJointStockCompanies' => $row['LocationLegalEntity'] ?? '',
            ]);

            $inventoryItem->BrandTMC = new BrandTMC([
                'IDBrandTMC' => (int) ($row['IDBrandTMC'] ?? 0),
                'NameBrand' => $row['NameBrand'] ?? '',
            ]);

            $user = new User([
                'IDUser' => (int) ($row['CurrentUser'] ?? 0),
                'Surname' => $row['Surname'] ?? '',
                'Name' => $row['Name'] ?? '',
                'Patronymic' => $row['Patronymic'] ?? '',
                'Status' => 0,
            ]);

            $currentUserId = (int) ($row['CurrentUser'] ?? 0);
            $registration = new RegistrationInventoryItem([
                'IDRegItem' => (int) ($row['IDRegItem'] ?? $tmcId),
                'CreatedUser' => $currentUserId,
                'CurrentUser' => $currentUserId,
            ]);
            $registration->User = $user;

            $repairs = $repairsByTmc[$tmcId] ?? [];
            if ($repairs) {
                $main = $repairs[0];
                $main->InventoryItem = $inventoryItem;
                $main->RegistrationInventoryItem = $registration;
                foreach ($repairs as $repair) {
                    $repair->InventoryItem = $inventoryItem;
                    $repair->RegistrationInventoryItem = $registration;
                }
            } else {
                $main = new RepairItem([
                    'ID_Repair' => 0,
                    'ID_TMC' => $tmcId,
                    'IDLocation' => (int) ($row['IDLocation'] ?? 0),
                    'RepairCost' => 0,
                    'InvoiceNumber' => '',
                    'RepairDescription' => '',
                    'DateToService' => date('Y-m-d H:i:s'),
                    'inBasket' => 0,
                ]);
                $main->InventoryItem = $inventoryItem;
                $main->RegistrationInventoryItem = $registration;
                $repairs = [$main];
            }

            $grouped[$tmcId] = [
                'main' => $main,
                'repairs' => $repairs,
            ];
        }

        return $grouped;
    }

    /**
     * Краткий список списанных для модалки на home.
     * Берём по Status=Списано, без истории ремонтов.
     */
    public function getWrittenOffSummary(int $limit = 50): array
    {
        $limit = max(1, min(200, (int) $limit));
        $statusWrittenOff = (int) StatusItem::WrittenOff;
        $sql = "
            SELECT TOP {$limit}
                ii.ID_TMC,
                ii.NameTMC,
                ii.SerialNumber,
                l.NameLocation,
                l.FormsJointStockCompanies AS LocationLegalEntity,
                b.NameBrand
            FROM InventoryItem ii
            LEFT JOIN Location l ON ii.IDLocation = l.IDLocation
            LEFT JOIN BrandTMC b ON ii.IDBrandTMC = b.IDBrandTMC
            WHERE ii.Status = {$statusWrittenOff}
            ORDER BY ii.ID_TMC DESC
        ";

        $pdo = DatabaseFactory::create()->getConnection();
        $stmt = $pdo->query($sql);
        if ($stmt === false) {
            // query() молча падает — лучше явная ошибка в json
            $error = $pdo->errorInfo();
            throw new Exception($error[2] ?? 'Ошибка запроса списанных ТМЦ');
        }

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $items = [];
        foreach ($rows as $row) {
            $items[] = [
                'id' => (int) ($row['ID_TMC'] ?? 0),
                'name' => (string) ($row['NameTMC'] ?? ''),
                'serial' => (string) ($row['SerialNumber'] ?? ''),
                'location' => (string) ($row['NameLocation'] ?? ''),
                'legal' => trim((string) ($row['LocationLegalEntity'] ?? '')),
                'brand' => (string) ($row['NameBrand'] ?? ''),
            ];
        }
        return $items;
    }
}
