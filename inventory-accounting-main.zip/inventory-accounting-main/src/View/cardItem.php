<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../storage/logs/cardItem.log');
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../BusinessLogic/ItemController.php';
require_once __DIR__ . '/../Database/DatabaseFactory.php';
require_once __DIR__ . '/../BusinessLogic/PropertyController.php';
require_once __DIR__ . '/../BusinessLogic/HistoryOperationsController.php';
require_once __DIR__ . '/../BusinessLogic/StatusItem.php';
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');

try {
    $currentID = $_GET['id'] ?? null;
    if (!$currentID) {
        echo '<div class="alert alert-info">Выберите элемент из списка</div>';
        exit;
    }
    $currentID = (int) $currentID;
    DatabaseFactory::setConfig();
    $propertyController = new PropertyController();
    $typeTMCs = $propertyController->getTypeTMC();

    $itemController = new ItemController();
    $inventoryItem = $itemController->getInventoryItem($currentID);
    $locations = $itemController->getLocations(false) ?? [];

    if ($inventoryItem && (int) ($inventoryItem->IDLocation ?? 0) > 0 && empty($inventoryItem->Location)) {
        foreach ($locations as $loc) {
            if ((int) $loc->IDLocation === (int) $inventoryItem->IDLocation) {
                $inventoryItem->Location = $loc;
                break;
            }
        }
    }

    $brandTMCs = $propertyController->getBrandsByTypeTMC($inventoryItem->IDTypesTMC);
    $modelTMCs = $propertyController->getModelsByBrand($inventoryItem->IDBrandTMC);
    $historyController = new HistoryOperationsController();
    $historyOperations = $historyController->getHistoryOperations($inventoryItem->ID_TMC);

    $currentLocationId = (int) ($inventoryItem->IDLocation ?? 0);
    $currentLegal = trim((string) ($inventoryItem->Location?->FormsJointStockCompanies ?? ''));
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Ошибка загрузки: ' . htmlspecialchars($e->getMessage()) . '</div>';
    exit;
}
?>

<link href="/styles/cardStyle.css" rel="stylesheet">

<div class="form-container" id="cardContainer"
    data-id="<?= (int) $inventoryItem->ID_TMC ?>"
    data-type="<?= (int) ($inventoryItem->IDTypesTMC ?? 0) ?>"
    data-brand="<?= (int) ($inventoryItem->IDBrandTMC ?? 0) ?>"
    data-model="<?= (int) ($inventoryItem->IDModel ?? 0) ?>"
    data-name="<?= htmlspecialchars($inventoryItem->NameTMC ?? '', ENT_QUOTES) ?>"
    data-serial="<?= htmlspecialchars((string) ($inventoryItem->SerialNumber ?? ''), ENT_QUOTES) ?>">
    <h3>Статус ТМЦ - <?= htmlspecialchars((new StatusItem())->getDescription($inventoryItem->Status) ?? '') ?></h3>

    <div class="form-group">
        <label class="lb" id="selectTypeTMC">Тип ТМЦ:</label>
        <select class="form-select" aria-label="Тип ТМЦ" id="idTypeTMC" disabled>
            <option value="0"></option>
            <?php foreach ($typeTMCs as $value): ?>
                <option value="<?= $value->IDTypesTMC ?>" <?= $value->IDTypesTMC == $inventoryItem->IDTypesTMC ? 'selected' : '' ?>>
                    <?= htmlspecialchars($value->NameTypesTMC) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label class="lb">Бренд:</label>
        <select class="form-select" aria-label="Бренд" id="idBrandTMC" disabled>
            <option value="0"></option>
            <?php foreach ($brandTMCs as $value): ?>
                <?php
                $brandId = (int) ($value->IDBrandTMC ?? $value->BrandTMC->IDBrandTMC ?? 0);
                $brandName = $value->NameBrand ?? $value->BrandTMC->NameBrand ?? '';
                ?>
                <option value="<?= $brandId ?>" <?= $brandId === (int) $inventoryItem->IDBrandTMC ? 'selected' : '' ?>>
                    <?= htmlspecialchars($brandName) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label class="lb">Модель:</label>
        <select class="form-select" aria-label="Модель" id="idModelTMC" disabled>
            <option value="0"></option>
            <?php foreach ($modelTMCs as $value): ?>
                <?php
                $modelId = (int) ($value->IDModel ?? $value->ModelTMC->IDModel ?? 0);
                $modelName = $value->NameModel ?? $value->ModelTMC->NameModel ?? '';
                ?>
                <option value="<?= $modelId ?>" <?= $modelId === (int) $inventoryItem->IDModel ? 'selected' : '' ?>>
                    <?= htmlspecialchars($modelName) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label class="lb">Наименование:</label>
        <textarea class="form-control auto-expand" id="txtNameTMC" name="nameTMC" placeholder="Укажите наименование"
            rows="1" aria-label="Наименование" readonly><?= htmlspecialchars($inventoryItem->NameTMC ?? '') ?></textarea>
    </div>

    <div class="form-group">
        <label class="lb">Серийный номер:</label>
        <input type="text" class="form-control" id="txtSerialNum" placeholder="Укажите серийный номер"
            aria-label="Серийный номер" readonly
            value="<?= htmlspecialchars($inventoryItem->SerialNumber ?: 'Серийный номер отсутствует') ?>">
    </div>

    <div class="form-group">
        <label class="lb" for="cardLocationSelect">Локация:</label>
        <select class="form-select" id="cardLocationSelect" name="idLocation">
            <option value="0">Не выбрана</option>
            <?php foreach ($locations as $loc): ?>
                <?php
                $locId = (int) ($loc->IDLocation ?? 0);
                $locLegal = trim((string) ($loc->FormsJointStockCompanies ?? ''));
                ?>
                <option value="<?= $locId ?>"
                    data-legal="<?= htmlspecialchars($locLegal, ENT_QUOTES) ?>"
                    <?= $currentLocationId === $locId ? 'selected' : '' ?>>
                    <?= htmlspecialchars($loc->NameLocation ?? '') ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label class="lb" for="cardLegalEntity">Юр. лицо:</label>
        <input type="text" class="form-control" id="cardLegalEntity" name="legalEntity"
            placeholder="Укажите юр. лицо локации"
            value="<?= htmlspecialchars($currentLegal) ?>">
        <div class="form-text" style="font-size:12px;color:#64748b;margin-top:4px;">
            Привязано к локации. Можно изменить и сохранить.
        </div>
    </div>

    <div class="form-group" style="display:flex;gap:8px;align-items:center;">
        <button type="button" class="btn btn-primary btn-sm" id="btnSaveCardLegal">
            Сохранить юр. лицо
        </button>
        <span id="cardLegalSaveStatus" style="font-size:12px;color:#64748b;"></span>
    </div>

    <div class="box" id="historyBox" style="grid-area: box-4">
        <div class="card-body">
            <h5 class="card-title" style="margin: 5px;">Последнии операции:</h5>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Дата </th>
                            <th>Операция </th>
                            <th>Отв. </th>
                        </tr>
                    </thead>
                </table>
                <div class="scroll-table-body">
                    <table>
                        <tbody id="tableBody">
                            <?php if ($historyOperations): ?>
                                <?php foreach ($historyOperations as $item): ?>
                                    <tr>
                                        <td><?= htmlspecialchars(date_create($item->HistoryData)->format('d.m.y')) ?></td>
                                        <td><?= htmlspecialchars($item->CommentsHistory->ValueComment ?? '—') ?></td>
                                        <td><?= htmlspecialchars($item->User->FIO ?? '—') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
