import { TypeMessage } from "../../src/constants/typeMessage.js";
import { showNotification } from "../modals/setting.js";
import { Action } from "../../src/constants/actions.js";

async function parseJsonResponse(response) {
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    const preview = text.replace(/\s+/g, " ").trim().slice(0, 160);
    if (preview.startsWith("<")) {
      throw new Error("Сервер вернул HTML вместо JSON. Проверьте лог на сервере.");
    }
    throw new Error(preview || "Ответ сервера не является JSON");
  }
}

/**
 * Универсальный шаблон для выполнения CUD операций с сущностями
 * @param {Object} config - Конфигурация операции
 * @param {string} config.action - Действие (CREATE, UPDATE, DELETE)
 * @param {Object} config.formData - Данные формы
 * @param {string} config.url - URL для обработки
 * @param {Function} [config.successCallback] - Колбэк при успешном выполнении
 * @param {Function} [config.errorCallback] - Колбэк при ошибке
 * @param {string} config.successMessage - Сообщение об успехе
 * @returns {Promise<Object>} Результат операции
 */
export async function executeEntityAction(config) {
  const {
    action,
    formData,
    url,
    successCallback,
    errorCallback,
    successMessage = "Операция выполнена успешно",
  } = config;

  try {
    // Добавляем действие в данные
    const requestData = {
      ...formData,
      statusEntity: action,
    };

    //console.log("requestData:");
    //console.log(requestData);
    //console.log(url);

    // Выполняем запрос
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestData),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await parseJsonResponse(response);

    if (result.success) {
      if (successMessage) {
        showNotification(TypeMessage.success, successMessage);
      }
      if (successCallback) {
        successCallback(result);
      }
      return result;
    } else {
      throw new Error(result.message || "Ошибка при выполнении операции");
    }
  } catch (error) {
    console.error(`Ошибка при выполнении действия ${action}:`, error);
    const errorMessage =
      error?.message || `Ошибка при выполнении действия ${action}`;

    if (errorCallback) {
      errorCallback(error);
    } else {
      showNotification(TypeMessage.error, errorMessage);
    }
    throw error;
  }
}
/**
 * Собирает данные формы в объект с указанным статусом действия
 * @param {HTMLFormElement} form - HTML-форма, из которой собираются данные
 * @param {Action} statusEntity - Статус действия (Create/Update/Delete)
 * @param {Object} [extraFields={}] - Дополнительные поля в формате {ключ: значение}
 * @returns {Object} Объект с данными формы и статусом действия
 */
export function getCollectFormData(form, statusEntity, extraFields = {}) {
  try {
    const formData = new FormData(form);
    const data = {
      statusEntity: statusEntity,
    };

    // Добавляем дополнительные поля, если они переданы
    if (extraFields && typeof extraFields === 'object') {
      Object.keys(extraFields).forEach(key => {
        data[key] = extraFields[key];
      });
    }

    // Преобразуем FormData в объект
    for (let [key, value] of formData.entries()) {
      data[key] = value;
    }

    return data;
  } catch (error) {
    console.error(`Ошибка при формировании коллекции:`, error);
  }
}